# Paróquia São Paulo Apóstolo — Carapicuíba

Site institucional da Paróquia São Paulo Apóstolo, com horários de missas, comunidades, pastorais, sacramentos, galeria, WebTV (transmissão ao vivo), agendamento de sacramentos e um painel administrativo simples para gerenciar avisos.

## Estrutura

```
frontend/   React (Create React App + Craco) + Tailwind CSS
backend/    FastAPI + MongoDB
```

## Como rodar localmente

### Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env      # preencha as variáveis
uvicorn server:app --reload --port 8000
```

### Frontend

```bash
cd frontend
yarn install               # ou npm install
cp .env.example .env       # preencha REACT_APP_BACKEND_URL
yarn start                 # ou npm start
```

O site abre em `http://localhost:3000`.

## Variáveis de ambiente

Veja `backend/.env.example` e `frontend/.env.example` para a lista completa (banco de dados, JWT, envio de e-mail via SMTP, credenciais do admin, etc).

## Deploy

Qualquer host que rode Node/React (front) e Python/FastAPI + MongoDB (back) funciona — por exemplo Vercel/Netlify para o front e Railway/Render/servidor próprio para o back.
