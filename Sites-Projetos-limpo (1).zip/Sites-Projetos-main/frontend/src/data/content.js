export const CONTACT = {
  phoneDisplay: "(11) 4184-1203",
  phoneHref: "tel:+551141841203",
  whatsapp: "https://wa.me/551141841203",
  email: "secretaria@pspa.com.br",
  address: "R. Rio Branco, 38 — Conj. Hab. Pres. Castelo Branco, Carapicuíba – SP, 06326-030",
  mapsUrl: "https://www.google.com/maps/search/?api=1&query=R.+Rio+Branco,+38,+Castelo+Branco,+Carapicu%C3%ADba,+SP",
  mapsEmbed: "https://www.google.com/maps?q=R.+Rio+Branco,+38,+Castelo+Branco,+Carapicu%C3%ADba,+SP&output=embed",
  instagram: "https://www.instagram.com/pspacarapicuiba/",
  youtube: "https://www.youtube.com/webtvpspa",
  facebook: "https://www.facebook.com/pspacarapicuiba/",
};

export const NAV_LINKS = [
  { id: "inicio", label: "Início" },
  { id: "missas", label: "Missas" },
  { id: "comunidades", label: "Comunidades" },
  { id: "pastorais", label: "Pastorais" },
  { id: "sacramentos", label: "Sacramentos" },
  { id: "historia", label: "História" },
  { id: "contato", label: "Contato" },
];

export const MASS_TIMES = {
  sabado: [
    { time: "19h30", place: "Comunidade São Benedito", note: "Santa Missa" },
  ],
  domingo: [
    { time: "07h30", place: "Matriz São Paulo Apóstolo", note: "Santa Missa" },
    { time: "09h00", place: "Comunidade São Pedro", note: "Santa Missa" },
    { time: "11h00", place: "Matriz São Paulo Apóstolo", note: "Santa Missa" },
    { time: "11h00", place: "Comunidade São Benedito", note: "Santa Missa" },
    { time: "17h00", place: "Comunidade São Pedro", note: "Santa Missa" },
    { time: "19h00", place: "Matriz São Paulo Apóstolo", note: "Transmissão ao vivo pela WebTV PSPA", live: true },
  ],
};

export const COMMUNITIES = [
  {
    name: "Matriz São Paulo Apóstolo",
    tag: "Sede da Paróquia",
    image: "/assets/missa1.png",
    address: "R. Rio Branco, 38 — Castelo Branco, Carapicuíba – SP",
    times: ["Dom 07h30", "Dom 11h00", "Dom 19h00"],
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=R.+Rio+Branco,+38,+Carapicu%C3%ADba,+SP",
  },
  {
    name: "Comunidade São Pedro",
    tag: "Comunidade",
    image: "/assets/sao-pedro-quadro.png",
    address: "Av. Antônio Faustino dos Santos, 620 — Castelo Branco, Carapicuíba – SP",
    times: ["Dom 09h00", "Dom 17h00"],
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=Av.+Ant%C3%B4nio+Faustino+dos+Santos,+620,+Carapicu%C3%ADba,+SP",
  },
  {
    name: "Comunidade São Benedito",
    tag: "Comunidade",
    image: "/assets/sao-benedito-quadro.png",
    address: "Rua Hortência, 112 — Vila Municipal, Carapicuíba – SP",
    times: ["Sáb 19h30", "Dom 11h00"],
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=Rua+Hort%C3%AAncia,+112,+Vila+Municipal,+Carapicu%C3%ADba,+SP",
  },
];

export const PASTORAIS = [
  { name: "Catequese", desc: "Formação na fé para crianças, jovens e adultos, preparando corações para os sacramentos.", icon: "BookOpen" },
  { name: "Pastoral do Dízimo", desc: "Conscientização sobre a partilha generosa que sustenta a missão evangelizadora da paróquia.", icon: "HandCoins" },
  { name: "Pastoral Litúrgica", desc: "Cuida da beleza e da ordem das celebrações, para que a liturgia seja sempre fonte de graça.", icon: "Church" },
  { name: "PASCOM", desc: "Pastoral da Comunicação: transmissões, redes sociais e a voz da paróquia no mundo digital.", icon: "Radio" },
  { name: "Ministros da Eucaristia", desc: "Ministros extraordinários que levam a Comunhão aos enfermos e auxiliam nas celebrações.", icon: "HandHeart" },
  { name: "Sociedade São Vicente de Paulo", desc: "Caridade concreta: visitas às famílias em situação de vulnerabilidade das nossas comunidades.", icon: "HeartHandshake" },
  { name: "Pastoral Familiar", desc: "Acolhida e acompanhamento das famílias, células vivas da nossa comunidade de fé.", icon: "Users" },
  { name: "Pastoral da Saúde", desc: "Presença e oração junto aos doentes, levando o conforto de Cristo aos que sofrem.", icon: "Cross" },
];

export const GRUPOS = [
  { name: "Terço dos Homens", desc: "Homens reunidos em oração mariana, fortalecendo a fé das famílias e da comunidade.", icon: "Shield" },
  { name: "Renovação Carismática", desc: "Grupos de oração que buscam a efusão do Espírito Santo e a vivência dos carismas.", icon: "Flame" },
  { name: "Legião de Maria", desc: "Apostolado mariano de oração e visita aos lares, presente desde os primeiros anos da comunidade.", icon: "Sparkles" },
  { name: "Apostolado da Oração", desc: "Rede de fiéis que oferecem o dia a dia em oração pelas intenções do Papa e da Igreja.", icon: "Sunrise" },
  { name: "Pastoral da Juventude", desc: "Jovens que evangelizam jovens, com encontros, retiros e missão nas comunidades.", icon: "Zap" },
  { name: "MECE", desc: "Ministros Extraordinários da Comunhão Eucarística a serviço do altar e dos enfermos.", icon: "Wine" },
  { name: "Coroinhas e Acólitos", desc: "Crianças e jovens que servem ao altar com alegria, aprendendo o amor pela liturgia.", icon: "Bell" },
  { name: "Grupo de Oração", desc: "Encontros semanais de louvor, intercessão e partilha da Palavra de Deus.", icon: "Music" },
];

export const SACRAMENTOS = [
  {
    num: "01",
    name: "Batismo",
    verse: "Porta de entrada da vida cristã",
    desc: "O primeiro sacramento, que nos faz filhos de Deus e membros da Igreja. Pais e padrinhos participam de encontro de preparação na secretaria paroquial.",
  },
  {
    num: "02",
    name: "Eucaristia",
    verse: "Fonte e ápice da vida cristã",
    desc: "A Primeira Comunhão é preparada pela catequese, conduzindo crianças e jovens ao encontro de Jesus no pão vivo descido do céu.",
  },
  {
    num: "03",
    name: "Crisma",
    verse: "Fortalecidos pelo Espírito",
    desc: "A confirmação dos dons do Batismo. Jovens e adultos são preparados para receber a plenitude do Espírito Santo e testemunhar a fé.",
  },
  {
    num: "04",
    name: "Reconciliação",
    verse: "O abraço da misericórdia",
    desc: "As confissões podem ser agendadas pela secretaria. O sacramento do perdão devolve a paz e a amizade com Deus.",
  },
  {
    num: "05",
    name: "Matrimônio",
    verse: "Amor que é aliança",
    desc: "Os noivos realizam curso de preparação e processo de habilitação com antecedência mínima de seis meses. Agende na secretaria.",
  },
  {
    num: "06",
    name: "Unção dos Enfermos",
    verse: "Cristo ao lado de quem sofre",
    desc: "Para doentes e idosos, em casa ou no hospital. A paróquia atende com carinho todos os pedidos de visita e unção.",
  },
];

export const HISTORIA = [
  {
    num: "01",
    year: "1971",
    title: "A Semente",
    text: "Padre Wilhelm Paulo Link chega ao Brasil e celebra sua primeira missa em Carapicuíba, na capela São Paulo Apóstolo do Jardim Planalto. Nascia ali o sonho de um templo para o povo da Cohab.",
  },
  {
    num: "02",
    year: "1972 — 1983",
    title: "O Sonho do Povo",
    text: "Os primeiros moradores do conjunto habitacional se reúnem no Centro Comunitário da Cohab II. Campanhas como o “carnê da construção” e o “cafezinho” sustentam a obra, e a cidade concede o terreno da Rua Rio Branco.",
  },
  {
    num: "03",
    year: "1984",
    title: "O Templo se Ergue",
    text: "Após muita luta e dedicação, o templo católico fica pronto, ao lado da Obra Kolping. Por votação democrática, o povo escolhe o padroeiro: São Paulo Apóstolo, fundador de comunidades e coluna da Igreja.",
  },
  {
    num: "04",
    year: "2000",
    title: "Elevada a Paróquia",
    text: "No dia 27 de outubro, sob o pontificado de São João Paulo II, Dom Francisco Manoel Vieira eleva a comunidade à Paróquia São Paulo Apóstolo, anexando as comunidades São Benedito e São Pedro.",
  },
  {
    num: "05",
    year: "Hoje",
    title: "A Missão Continua",
    text: "Sob a condução do Pe. Jefferson Bezerra de Almeida, administrador paroquial, a paróquia segue acolhendo milhares de fiéis em suas três comunidades, unida pela fé e pela caridade.",
  },
];

export const PAROQUIA_QUOTE = {
  text: "Combati o bom combate, terminei a minha carreira, guardei a fé.",
  ref: "2 Timóteo 4,7",
};

export const YOUTUBE_CHANNEL_ID = "UCQEKj8_LPQz0gFmP6RlA3GQ";
export const YOUTUBE_LIVE_EMBED = `https://www.youtube.com/embed/live_stream?channel=${YOUTUBE_CHANNEL_ID}&autoplay=1&rel=0`;

export const AVISOS_FALLBACK = [
  { id: "f1", titulo: "Missa transmitida ao vivo", data: "Todo domingo · 19h", tag: "Transmissão", texto: "Santa Missa da Matriz transmitida ao vivo pela WebTV PSPA no YouTube. Reze conosco de onde estiver." },
  { id: "f2", titulo: "Dozenário de São Benedito", data: "26/09 a 07/10 · 20h", tag: "Festa", texto: "Celebrações em honra a São Benedito na Comunidade São Benedito. Participe com sua família." },
  { id: "f3", titulo: "Solenidade de Nossa Senhora Aparecida", data: "12/10 · 9h", tag: "Festa", texto: "Celebração solene da padroeira do Brasil na Matriz São Paulo Apóstolo." },
];

export const GALLERY = [
  { src: "/assets/missa1.png", caption: "Santa Missa na Matriz" },
  { src: "/assets/missa2.png", caption: "Celebração com a comunidade" },
  { src: "/assets/missa3.png", caption: "Procissão e fé" },
  { src: "/assets/missa4.png", caption: "Nosso templo" },
  { src: "/assets/comunidade1.png", caption: "Vida paroquial" },
  { src: "/assets/comunidade2.png", caption: "Momentos de oração" },
  { src: "/assets/comunidade3.png", caption: "Nossa gente" },
  { src: "/assets/galeria9.png", caption: "Comunidade São Pedro" },
  { src: "/assets/galeria10.png", caption: "Celebrações em São Pedro" },
  { src: "/assets/galeria11.png", caption: "Comunidade São Benedito" },
  { src: "/assets/galeria12.png", caption: "A Eucaristia no centro" },
  { src: "/assets/galeria13.png", caption: "Fé que nos une" },
  { src: "/assets/galeria14.png", caption: "Alegria de ser igreja" },
];
