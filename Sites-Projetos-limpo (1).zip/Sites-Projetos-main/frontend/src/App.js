import { useEffect } from "react";
import "@/App.css";
import Lenis from "lenis";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "sonner";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { Marquee } from "./components/Marquee";
import { Announcements } from "./components/Announcements";
import { MassTimes } from "./components/MassTimes";
import { Communities } from "./components/Communities";
import { Gallery } from "./components/Gallery";
import { WebTV } from "./components/WebTV";
import { Pastorals } from "./components/Pastorals";
import { Sacraments } from "./components/Sacraments";
import { BookingForm } from "./components/BookingForm";
import { History } from "./components/History";
import { Contact, Footer } from "./components/Contact";
import Admin from "./pages/Admin";

const Landing = () => (
  <>
    <Navbar />
    <main>
      <Hero />
      <Marquee />
      <Announcements />
      <MassTimes />
      <Communities />
      <Gallery />
      <WebTV />
      <Pastorals />
      <Sacraments />
      <BookingForm />
      <History />
      <Contact />
    </main>
    <Footer />
  </>
);

function App() {
  useEffect(() => {
    const lenis = new Lenis({ lerp: 0.085, smoothWheel: true });
    window.__lenis = lenis;
    let rafId;
    const raf = (time) => {
      lenis.raf(time);
      rafId = requestAnimationFrame(raf);
    };
    rafId = requestAnimationFrame(raf);
    return () => {
      cancelAnimationFrame(rafId);
      lenis.destroy();
      window.__lenis = null;
    };
  }, []);

  return (
    <div className="App">
      <div className="grain-overlay" aria-hidden />
      <Toaster richColors position="top-center" />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
