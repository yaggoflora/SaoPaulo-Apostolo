import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  BookOpen, HandCoins, Church, Radio, HandHeart, HeartHandshake, Users, Cross,
  Shield, Flame, Sparkles, Sunrise, Zap, Wine, Bell, Music,
} from "lucide-react";
import { PASTORAIS, GRUPOS } from "../data/content";
import { Reveal, SectionHeading, EASE } from "./Reveal";

const ICONS = {
  BookOpen, HandCoins, Church, Radio, HandHeart, HeartHandshake, Users, Cross,
  Shield, Flame, Sparkles, Sunrise, Zap, Wine, Bell, Music,
};

const TABS = [
  { key: "pastorais", label: "Pastorais", data: PASTORAIS },
  { key: "grupos", label: "Grupos e Movimentos", data: GRUPOS },
];

export const Pastorals = () => {
  const [tab, setTab] = useState("pastorais");
  const active = TABS.find((t) => t.key === tab);

  return (
    <section id="pastorais" data-testid="pastorals-section" className="relative py-24 sm:py-32 bg-cream-100 overflow-hidden">
      <div className="absolute bottom-0 left-0 w-[480px] h-[480px] rounded-full bg-gold-100 blur-3xl opacity-70 translate-y-1/2 -translate-x-1/3" />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <div className="text-center max-w-2xl mx-auto">
          <SectionHeading align="center" kicker="Participe" title={<>Pastorais, Grupos<br />e Movimentos</>} />
          <Reveal delay={0.2}>
            <p className="mt-6 text-ink-600 text-base sm:text-lg leading-relaxed">
              A paróquia é feita de pessoas que servem com alegria. Encontre o
              seu lugar e venha caminhar conosco.
            </p>
          </Reveal>
        </div>

        <Reveal delay={0.25}>
          <div className="mt-10 flex justify-center">
            <div className="inline-flex flex-wrap justify-center rounded-full border border-cream-300 bg-white p-1.5 shadow-sm" role="tablist" aria-label="Pastorais e grupos">
              {TABS.map((t) => (
                <button
                  key={t.key}
                  data-testid={`pastorals-tab-${t.key}`}
                  role="tab"
                  aria-selected={tab === t.key}
                  onClick={() => setTab(t.key)}
                  className={`relative rounded-full px-6 sm:px-8 py-2.5 text-xs sm:text-sm font-bold uppercase tracking-wide transition-colors duration-300 ${
                    tab === t.key ? "text-cream-50" : "text-ink-600 hover:text-crimson-700"
                  }`}
                >
                  {tab === t.key && (
                    <motion.span
                      layoutId="pastorals-tab-pill"
                      className="absolute inset-0 rounded-full bg-crimson-700"
                      transition={{ duration: 0.45, ease: EASE }}
                    />
                  )}
                  <span className="relative z-10">{t.label}</span>
                </button>
              ))}
            </div>
          </div>
        </Reveal>

        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.5, ease: EASE }}
            className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-5"
          >
            {active.data.map((item, i) => {
              const Icon = ICONS[item.icon] || Church;
              return (
                <motion.article
                  key={item.name}
                  data-testid={`pastoral-card-${tab}-${i}`}
                  initial={{ opacity: 0, y: 28 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.55, delay: 0.05 * i, ease: EASE }}
                  whileHover={{ y: -6 }}
                  className="group relative rounded-2xl border border-cream-200 bg-white p-6 shadow-[0_4px_18px_rgba(90,0,18,0.05)] hover:shadow-[0_18px_44px_rgba(90,0,18,0.13)] hover:border-gold-500/40 transition-[box-shadow,border-color] duration-400 overflow-hidden"
                >
                  <div className="absolute top-0 left-0 h-1 w-0 bg-gradient-to-r from-crimson-700 to-gold-500 transition-all duration-500 group-hover:w-full" />
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-crimson-100 text-crimson-700 group-hover:bg-crimson-700 group-hover:text-gold-300 transition-colors duration-400">
                    <Icon size={22} />
                  </div>
                  <h3 className="mt-5 font-serif font-bold text-xl text-ink-900 leading-snug">{item.name}</h3>
                  <p className="mt-2.5 text-sm text-ink-600 leading-relaxed">{item.desc}</p>
                </motion.article>
              );
            })}
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
};
