const ITEMS = [
  "Santa Missa",
  "Domingos 07h30 · 09h00 · 11h00 · 17h00 · 19h00",
  "Sábados 19h30",
  "Transmissão ao vivo pela WebTV PSPA",
  "Paróquia São Paulo Apóstolo",
  "Carapicuíba — SP",
];

export const Marquee = () => (
  <div data-testid="editorial-marquee" className="relative overflow-hidden bg-crimson-800 border-y border-gold-500/25 py-5" aria-hidden>
    <div className="flex w-max animate-marquee">
      {[0, 1].map((copy) => (
        <div key={copy} className="flex shrink-0 items-center">
          {ITEMS.map((item, i) => (
            <span key={`${copy}-${i}`} className="flex items-center">
              <span className="font-serif italic text-cream-100/90 text-lg sm:text-xl whitespace-nowrap px-6">
                {item}
              </span>
              <span className="text-gold-400 text-sm">✦</span>
            </span>
          ))}
        </div>
      ))}
    </div>
  </div>
);
