import { motion } from "framer-motion";
import { MapPin, Clock, MessageCircle } from "lucide-react";
import { COMMUNITIES, CONTACT } from "../data/content";
import { Reveal, SectionHeading, EASE } from "./Reveal";

export const Communities = () => (
  <section id="comunidades" data-testid="communities-section" className="relative py-24 sm:py-32 bg-ink-950 overflow-hidden">
    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(139,0,29,0.35),transparent_55%)]" />
    <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
      <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8">
        <SectionHeading dark kicker="Nossas Comunidades" title={<>Uma paróquia,<br />três famílias</>} />
        <Reveal delay={0.2} className="max-w-md">
          <p className="text-cream-100/60 text-base sm:text-lg leading-relaxed lg:text-right">
            A Matriz se estende para além de seus muros, abraçando as
            comunidades de São Pedro e São Benedito. Cada uma é um lugar
            especial de devoção.
          </p>
        </Reveal>
      </div>

      <div className="mt-16 grid md:grid-cols-3 gap-6 lg:gap-8">
        {COMMUNITIES.map((c, i) => (
          <motion.article
            key={c.name}
            data-testid={`community-card-${i}`}
            initial={{ opacity: 0, y: 48 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.85, delay: 0.12 * i, ease: EASE }}
            whileHover={{ y: -8 }}
            className="group relative rounded-3xl overflow-hidden bg-ink-900 border border-gold-500/15 hover:border-gold-500/45 transition-[border-color] duration-500 shadow-[0_20px_60px_rgba(0,0,0,0.4)]"
          >
            <div className="relative h-64 overflow-hidden">
              <img
                src={c.image}
                alt={c.name}
                className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-900 via-transparent to-transparent" />
              <span className="absolute top-4 left-4 rounded-full bg-crimson-700/90 backdrop-blur text-gold-300 text-[10px] font-bold uppercase tracking-[0.18em] px-3.5 py-1.5">
                {c.tag}
              </span>
            </div>
            <div className="p-6 sm:p-7">
              <h3 className="font-serif font-bold text-2xl text-cream-50 leading-tight">{c.name}</h3>
              <p className="mt-3 flex items-start gap-2 text-sm text-cream-100/55 leading-relaxed">
                <MapPin size={15} className="mt-0.5 shrink-0 text-gold-500" />
                {c.address}
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {c.times.map((t) => (
                  <span key={t} className="inline-flex items-center gap-1.5 rounded-full border border-gold-500/25 text-gold-300/90 text-xs font-semibold px-3 py-1.5">
                    <Clock size={12} />
                    {t}
                  </span>
                ))}
              </div>
              <div className="mt-6 flex gap-3">
                <a
                  data-testid={`community-directions-${i}`}
                  href={c.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 inline-flex items-center justify-center gap-2 rounded-full bg-gold-500 hover:bg-gold-400 text-ink-950 text-xs font-bold uppercase tracking-wide px-4 py-3 transition-all duration-300"
                >
                  <MapPin size={14} />
                  Como chegar
                </a>
                <a
                  data-testid={`community-whatsapp-${i}`}
                  href={CONTACT.whatsapp}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`Agendar na ${c.name} pelo WhatsApp`}
                  className="inline-flex items-center justify-center rounded-full border border-cream-50/20 hover:border-gold-400 text-cream-50 hover:text-gold-300 w-11 h-11 transition-colors duration-300"
                >
                  <MessageCircle size={17} />
                </a>
              </div>
            </div>
          </motion.article>
        ))}
      </div>
    </div>
  </section>
);
