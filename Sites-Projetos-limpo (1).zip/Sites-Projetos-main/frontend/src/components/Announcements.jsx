import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Megaphone, CalendarDays } from "lucide-react";
import api from "../lib/api";
import { AVISOS_FALLBACK } from "../data/content";
import { Reveal, EASE } from "./Reveal";

export const Announcements = () => {
  const [avisos, setAvisos] = useState(AVISOS_FALLBACK);

  useEffect(() => {
    api.get("/avisos")
      .then((r) => { if (Array.isArray(r.data) && r.data.length) setAvisos(r.data); })
      .catch(() => {});
  }, []);

  return (
    <section id="avisos" data-testid="announcements-section" className="relative bg-white border-b border-cream-200 py-14 sm:py-16 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <div className="flex items-center gap-4">
          <Reveal>
            <span className="flex h-11 w-11 items-center justify-center rounded-full bg-crimson-700 text-gold-300">
              <Megaphone size={19} />
            </span>
          </Reveal>
          <Reveal delay={0.08}>
            <div>
              <p className="text-[11px] font-sans font-bold uppercase tracking-[0.28em] text-gold-700">Avisos da Semana</p>
              <h2 className="font-serif font-bold text-2xl sm:text-3xl text-ink-900 tracking-tight">Fique por dentro</h2>
            </div>
          </Reveal>
        </div>

        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {avisos.slice(0, 6).map((a, i) => (
            <motion.article
              key={a.id || i}
              data-testid={`announcement-card-${i}`}
              initial={{ opacity: 0, y: 26 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.65, delay: 0.07 * i, ease: EASE }}
              whileHover={{ y: -5 }}
              className="group relative rounded-2xl border border-cream-200 bg-cream-50 p-6 hover:border-gold-500/50 hover:shadow-[0_16px_40px_rgba(90,0,18,0.1)] transition-[box-shadow,border-color] duration-400"
            >
              <div className="flex items-center justify-between gap-3">
                <span className="rounded-full bg-crimson-100 text-crimson-700 text-[10px] font-bold uppercase tracking-[0.16em] px-3 py-1.5">
                  {a.tag}
                </span>
                {a.data && (
                  <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-gold-700">
                    <CalendarDays size={13} />
                    {a.data}
                  </span>
                )}
              </div>
              <h3 className="mt-4 font-serif font-bold text-xl text-ink-900 leading-snug">{a.titulo}</h3>
              <p className="mt-2 text-sm text-ink-600 leading-relaxed">{a.texto}</p>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
};
