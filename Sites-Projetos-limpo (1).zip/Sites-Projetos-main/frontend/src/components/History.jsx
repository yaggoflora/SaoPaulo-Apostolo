import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { HISTORIA, PAROQUIA_QUOTE } from "../data/content";
import { Reveal, SectionHeading, EASE } from "./Reveal";

export const History = () => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const imgY = useTransform(scrollYProgress, [0, 1], [70, -70]);

  return (
    <section id="historia" ref={ref} data-testid="history-section" className="relative py-24 sm:py-32 bg-ink-950 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(212,175,55,0.1),transparent_50%)]" />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <SectionHeading dark kicker="Nossa História" title={<>Cinco capítulos<br />de fé e comunidade</>} />

        <div className="mt-16 grid lg:grid-cols-[1fr_0.72fr] gap-14">
          <div className="flex flex-col">
            {HISTORIA.map((h, i) => (
              <motion.div
                key={h.num}
                data-testid={`history-chapter-${i}`}
                initial={{ opacity: 0, x: -36 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.8, delay: 0.05 * i, ease: EASE }}
                className="group relative flex gap-6 sm:gap-9 pb-12 last:pb-0"
              >
                {i < HISTORIA.length - 1 && (
                  <span className="absolute left-[27px] sm:left-[35px] top-16 bottom-0 w-px bg-gradient-to-b from-gold-500/50 to-crimson-700/20" />
                )}
                <div className="relative shrink-0">
                  <div className="flex h-14 w-14 sm:h-[72px] sm:w-[72px] items-center justify-center rounded-full border border-gold-500/40 bg-ink-900 group-hover:bg-crimson-800 transition-colors duration-500">
                    <span className="font-display text-gold-400 text-lg sm:text-2xl font-semibold">{h.num}</span>
                  </div>
                </div>
                <div className="pt-1">
                  <p className="text-[11px] font-sans font-bold uppercase tracking-[0.3em] text-gold-500">{h.year}</p>
                  <h3 className="mt-2 font-serif font-bold text-2xl sm:text-3xl text-cream-50 tracking-tight">{h.title}</h3>
                  <p className="mt-3 text-sm sm:text-base text-cream-100/60 leading-relaxed max-w-xl">{h.text}</p>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="relative">
            <motion.div style={{ y: imgY }} className="lg:sticky lg:top-28">
              <Reveal delay={0.2}>
                <div className="relative rounded-3xl overflow-hidden border border-gold-500/25 shadow-[0_30px_70px_rgba(0,0,0,0.5)]">
                  <img src="/assets/missa4.png" alt="Interior da Paróquia São Paulo Apóstolo" className="w-full h-[300px] sm:h-[400px] object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-950/90 via-ink-950/20 to-transparent" />
                  <blockquote className="absolute bottom-0 left-0 right-0 p-6 sm:p-8">
                    <p className="font-serif italic text-cream-50 text-xl sm:text-2xl leading-snug">
                      “{PAROQUIA_QUOTE.text}”
                    </p>
                    <cite className="mt-3 block text-gold-400 text-xs font-sans font-bold uppercase tracking-[0.25em] not-italic">
                      São Paulo · {PAROQUIA_QUOTE.ref}
                    </cite>
                  </blockquote>
                </div>
              </Reveal>
              <Reveal delay={0.35}>
                <p className="mt-6 text-cream-100/45 text-sm leading-relaxed">
                  Desde as capelas da Estrada da Aldeia, em 1580, até a elevação
                  à paróquia em 27 de outubro de 2000: uma história escrita pelo
                  povo de Carapicuíba.
                </p>
              </Reveal>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};
