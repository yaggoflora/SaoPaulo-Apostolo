import { useState } from "react";
import { motion } from "framer-motion";
import { CalendarCheck, Send, Loader2 } from "lucide-react";
import { toast } from "sonner";
import api, { formatApiError } from "../lib/api";
import { Reveal, SectionHeading, EASE } from "./Reveal";

const TIPOS = ["Batismo", "Casamento", "Confissão", "Outro"];
const EMPTY = { tipo: "Batismo", nome: "", telefone: "", email: "", data_preferida: "", mensagem: "" };

const inputCls = "w-full rounded-xl border border-cream-200 bg-cream-50 px-4 py-3.5 text-sm text-ink-900 placeholder:text-ink-600/40 outline-none focus:border-crimson-600 focus:ring-2 focus:ring-crimson-600/15 transition-all duration-300";

export const BookingForm = () => {
  const [form, setForm] = useState(EMPTY);
  const [sending, setSending] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setSending(true);
    try {
      await api.post("/agendamentos", { ...form, email: form.email || null });
      toast.success("Pedido enviado com sucesso! A secretaria entrará em contato.");
      setForm(EMPTY);
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail));
    } finally {
      setSending(false);
    }
  };

  return (
    <section id="agendamento" data-testid="booking-section" className="relative py-24 sm:py-32 bg-crimson-900 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(212,175,55,0.14),transparent_55%)]" />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 grid lg:grid-cols-[0.85fr_1.15fr] gap-14 items-start">
        <div className="lg:sticky lg:top-28">
          <SectionHeading dark kicker="Agendamento Online" title={<>Agende seu<br />sacramento</>} />
          <Reveal delay={0.2}>
            <p className="mt-6 text-cream-100/70 text-base sm:text-lg leading-relaxed max-w-md">
              Preencha o pedido de batismo, casamento ou confissão e ele chega
              direto à nossa secretaria. Retornaremos para confirmar todos os
              detalhes com você.
            </p>
          </Reveal>
          <Reveal delay={0.3}>
            <div className="mt-8 flex items-center gap-4 rounded-2xl border border-gold-500/25 bg-crimson-800/60 p-5">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gold-500 text-ink-950">
                <CalendarCheck size={18} />
              </span>
              <p className="text-sm text-cream-100/70 leading-relaxed">
                Casamentos exigem preparação com antecedência mínima de seis meses.
              </p>
            </div>
          </Reveal>
        </div>

        <Reveal delay={0.15}>
          <motion.form
            data-testid="booking-form"
            onSubmit={submit}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: EASE }}
            className="rounded-3xl bg-white p-6 sm:p-9 shadow-[0_30px_80px_rgba(0,0,0,0.35)] border border-gold-500/20"
          >
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label htmlFor="booking-tipo" className="block text-[11px] font-bold uppercase tracking-[0.18em] text-gold-700 mb-2">O que deseja agendar?</label>
                <select
                  id="booking-tipo"
                  data-testid="booking-tipo-select"
                  value={form.tipo}
                  onChange={set("tipo")}
                  className={inputCls}
                >
                  {TIPOS.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label htmlFor="booking-nome" className="block text-[11px] font-bold uppercase tracking-[0.18em] text-gold-700 mb-2">Nome completo</label>
                <input id="booking-nome" data-testid="booking-nome-input" required value={form.nome} onChange={set("nome")} placeholder="Seu nome" className={inputCls} />
              </div>
              <div>
                <label htmlFor="booking-telefone" className="block text-[11px] font-bold uppercase tracking-[0.18em] text-gold-700 mb-2">Telefone / WhatsApp</label>
                <input id="booking-telefone" data-testid="booking-telefone-input" required value={form.telefone} onChange={set("telefone")} placeholder="(11) 90000-0000" className={inputCls} />
              </div>
              <div>
                <label htmlFor="booking-email" className="block text-[11px] font-bold uppercase tracking-[0.18em] text-gold-700 mb-2">E-mail (opcional)</label>
                <input id="booking-email" data-testid="booking-email-input" type="email" value={form.email} onChange={set("email")} placeholder="voce@email.com" className={inputCls} />
              </div>
              <div>
                <label htmlFor="booking-data" className="block text-[11px] font-bold uppercase tracking-[0.18em] text-gold-700 mb-2">Data preferida</label>
                <input id="booking-data" data-testid="booking-data-input" type="date" value={form.data_preferida} onChange={set("data_preferida")} className={inputCls} />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="booking-mensagem" className="block text-[11px] font-bold uppercase tracking-[0.18em] text-gold-700 mb-2">Mensagem</label>
                <textarea id="booking-mensagem" data-testid="booking-mensagem-input" rows={4} value={form.mensagem} onChange={set("mensagem")} placeholder="Conte um pouco sobre o pedido (padrinhos, comunidade preferida, etc.)" className={`${inputCls} resize-none`} />
              </div>
            </div>
            <button
              data-testid="booking-submit-button"
              type="submit"
              disabled={sending}
              className="mt-6 w-full inline-flex items-center justify-center gap-2.5 rounded-full bg-crimson-700 hover:bg-crimson-600 text-cream-50 font-bold text-sm uppercase tracking-wide px-8 py-4 transition-all duration-300 hover:shadow-[0_14px_36px_rgba(139,0,29,0.35)] disabled:opacity-60"
            >
              {sending ? <Loader2 size={17} className="animate-spin" /> : <Send size={17} />}
              {sending ? "Enviando..." : "Enviar pedido à secretaria"}
            </button>
            <p className="mt-4 text-center text-xs text-ink-600/60">
              Seus dados são usados apenas para o contato da secretaria paroquial.
            </p>
          </motion.form>
        </Reveal>
      </div>
    </section>
  );
};
