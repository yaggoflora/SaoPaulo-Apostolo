import { useCallback, useEffect, useState } from "react";
import useEmblaCarousel from "embla-carousel-react";
import { ChevronLeft, ChevronRight, Camera } from "lucide-react";
import { GALLERY } from "../data/content";
import { Reveal, SectionHeading } from "./Reveal";

export const Gallery = () => {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true, align: "start", skipSnaps: false });
  const [canPrev, setCanPrev] = useState(false);
  const [canNext, setCanNext] = useState(false);

  const sync = useCallback((api) => {
    setCanPrev(api.canScrollPrev());
    setCanNext(api.canScrollNext());
  }, []);

  useEffect(() => {
    if (!emblaApi) return;
    sync(emblaApi);
    emblaApi.on("select", () => sync(emblaApi));
    emblaApi.on("reInit", () => sync(emblaApi));
  }, [emblaApi, sync]);

  useEffect(() => {
    if (!emblaApi) return;
    const id = setInterval(() => emblaApi.scrollNext(), 4200);
    const stop = () => clearInterval(id);
    emblaApi.on("pointerDown", stop);
    return () => clearInterval(id);
  }, [emblaApi]);

  return (
    <section id="galeria" data-testid="gallery-section" className="relative py-24 sm:py-32 bg-cream-50 overflow-hidden">
      <div className="absolute top-1/3 left-0 w-[420px] h-[420px] rounded-full bg-gold-100 blur-3xl opacity-60 -translate-x-1/2" />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8">
          <SectionHeading kicker="Galeria" title={<>Momentos da<br />nossa comunidade</>} />
          <Reveal delay={0.2} className="flex items-center gap-3">
            <button
              data-testid="gallery-prev-button"
              onClick={() => emblaApi && emblaApi.scrollPrev()}
              disabled={!canPrev}
              aria-label="Foto anterior"
              className="flex h-12 w-12 items-center justify-center rounded-full border border-cream-300 text-ink-800 hover:border-crimson-700 hover:text-crimson-700 transition-colors duration-300 disabled:opacity-30"
            >
              <ChevronLeft size={20} />
            </button>
            <button
              data-testid="gallery-next-button"
              onClick={() => emblaApi && emblaApi.scrollNext()}
              disabled={!canNext}
              aria-label="Próxima foto"
              className="flex h-12 w-12 items-center justify-center rounded-full bg-crimson-700 text-cream-50 hover:bg-crimson-600 transition-colors duration-300 disabled:opacity-30"
            >
              <ChevronRight size={20} />
            </button>
          </Reveal>
        </div>

        <Reveal delay={0.25}>
          <div className="mt-12 overflow-hidden" ref={emblaRef} data-testid="gallery-carousel">
            <div className="flex gap-5">
              {GALLERY.map((g, i) => (
                <figure
                  key={g.src}
                  data-testid={`gallery-slide-${i}`}
                  className="group relative shrink-0 basis-[85%] sm:basis-[46%] lg:basis-[31%] rounded-3xl overflow-hidden border border-cream-200 shadow-[0_10px_30px_rgba(90,0,18,0.08)]"
                >
                  <img
                    src={g.src}
                    alt={g.caption}
                    loading="lazy"
                    className="h-72 sm:h-96 w-full object-cover transition-transform duration-700 ease-out group-hover:scale-108"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-950/75 via-transparent to-transparent opacity-80" />
                  <figcaption className="absolute bottom-0 left-0 right-0 p-5 flex items-center gap-2.5">
                    <Camera size={15} className="text-gold-400 shrink-0" />
                    <span className="font-serif italic text-cream-50 text-base sm:text-lg">{g.caption}</span>
                  </figcaption>
                </figure>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
};
