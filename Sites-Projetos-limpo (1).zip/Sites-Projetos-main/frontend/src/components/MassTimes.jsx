import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Radio, Phone, Church } from "lucide-react";
import { MASS_TIMES, CONTACT } from "../data/content";
import { Reveal, SectionHeading, EASE } from "./Reveal";

const TABS = [
  { key: "sabado", label: "Sábado" },
  { key: "domingo", label: "Domingo" },
];

export const MassTimes = () => {
  const [tab, setTab] = useState("domingo");

  return (
    <section id="missas" data-testid="mass-schedule-section" className="relative py-24 sm:py-32 bg-cream-50 overflow-hidden">
      <div className="absolute top-0 right-0 w-[520px] h-[520px] rounded-full bg-gold-100 blur-3xl opacity-60 -translate-y-1/2 translate-x-1/3" />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
        <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-14 items-start">
          <div className="lg:sticky lg:top-28">
            <SectionHeading kicker="Horários" title={<>Missas e<br />Celebrações</>} />
            <Reveal delay={0.15}>
              <p className="mt-6 text-ink-600 text-base sm:text-lg leading-relaxed max-w-md">
                A Eucaristia é o coração da nossa paróquia. Escolha a comunidade
                mais perto de você e venha celebrar conosco.
              </p>
            </Reveal>
            <Reveal delay={0.25}>
              <div className="mt-8 flex items-start gap-4 rounded-2xl border border-gold-500/25 bg-gold-100/60 p-5">
                <span className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-crimson-700 text-cream-50">
                  <Radio size={18} />
                </span>
                <div>
                  <p className="font-serif font-semibold text-ink-900">Transmissão ao vivo</p>
                  <p className="text-sm text-ink-600 mt-1 leading-relaxed">
                    Todos os domingos às 19h, direto da Matriz pela WebTV PSPA no YouTube.
                  </p>
                </div>
              </div>
            </Reveal>
            <Reveal delay={0.35}>
              <a
                data-testid="mass-confession-button"
                href={CONTACT.phoneHref}
                className="mt-6 inline-flex items-center gap-2 text-crimson-700 font-semibold text-sm uppercase tracking-wide hover:text-crimson-600 transition-colors"
              >
                <Phone size={16} />
                Confissões e agendamentos: {CONTACT.phoneDisplay}
              </a>
            </Reveal>
          </div>

          <div>
            <Reveal delay={0.1}>
              <div className="inline-flex rounded-full border border-cream-300 bg-white p-1.5 shadow-sm" role="tablist" aria-label="Dias de celebração">
                {TABS.map((t) => (
                  <button
                    key={t.key}
                    data-testid={`mass-tab-${t.key}`}
                    role="tab"
                    aria-selected={tab === t.key}
                    onClick={() => setTab(t.key)}
                    className={`relative rounded-full px-7 py-2.5 text-sm font-bold uppercase tracking-wide transition-colors duration-300 ${
                      tab === t.key ? "text-cream-50" : "text-ink-600 hover:text-crimson-700"
                    }`}
                  >
                    {tab === t.key && (
                      <motion.span
                        layoutId="mass-tab-pill"
                        className="absolute inset-0 rounded-full bg-crimson-700"
                        transition={{ duration: 0.45, ease: EASE }}
                      />
                    )}
                    <span className="relative z-10">{t.label}</span>
                  </button>
                ))}
              </div>
            </Reveal>

            <AnimatePresence mode="wait">
              <motion.div
                key={tab}
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.45, ease: EASE }}
                className="mt-8 flex flex-col gap-4"
              >
                {MASS_TIMES[tab].map((m, i) => (
                  <motion.div
                    key={`${tab}-${i}`}
                    data-testid={`mass-card-${tab}-${i}`}
                    initial={{ opacity: 0, x: 30 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.55, delay: 0.07 * i, ease: EASE }}
                    whileHover={{ x: 6 }}
                    className="group flex items-center gap-5 rounded-2xl border border-cream-200 bg-white p-5 sm:p-6 shadow-[0_4px_20px_rgba(90,0,18,0.05)] hover:shadow-[0_16px_40px_rgba(90,0,18,0.12)] hover:border-gold-500/40 transition-[box-shadow,border-color] duration-400"
                  >
                    <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-crimson-100 text-crimson-700 group-hover:bg-crimson-700 group-hover:text-gold-300 transition-colors duration-400">
                      <Church size={24} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-serif font-bold text-2xl sm:text-3xl text-ink-900 tracking-tight">{m.time}</p>
                      <p className="text-sm sm:text-base text-ink-600 mt-0.5">{m.place}</p>
                    </div>
                    <div className="text-right shrink-0">
                      {m.live ? (
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-crimson-700 text-cream-50 text-[10px] font-bold uppercase tracking-wider px-3 py-1.5">
                          <span className="h-1.5 w-1.5 rounded-full bg-gold-400 animate-pulse-dot" />
                          Ao vivo
                        </span>
                      ) : (
                        <span className="text-[11px] font-semibold uppercase tracking-wider text-gold-700">{m.note}</span>
                      )}
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
};
