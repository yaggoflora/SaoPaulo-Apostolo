import { motion } from "framer-motion";

export const EASE = [0.22, 1, 0.36, 1];

export const Reveal = ({ children, delay = 0, y = 36, className = "" }) => (
  <motion.div
    className={className}
    initial={{ opacity: 0, y }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: "-70px" }}
    transition={{ duration: 0.9, delay, ease: EASE }}
  >
    {children}
  </motion.div>
);

export const SectionHeading = ({ kicker, title, dark = false, align = "left" }) => (
  <div className={align === "center" ? "text-center" : ""}>
    <Reveal>
      <p className={`text-xs font-sans font-bold uppercase tracking-[0.28em] ${dark ? "text-gold-400" : "text-crimson-700"}`}>
        {kicker}
      </p>
    </Reveal>
    <Reveal delay={0.08}>
      <h2 className={`mt-4 font-serif font-bold tracking-tight leading-[1.05] text-4xl sm:text-5xl lg:text-6xl ${dark ? "text-cream-50" : "text-ink-900"}`}>
        {title}
      </h2>
    </Reveal>
  </div>
);
