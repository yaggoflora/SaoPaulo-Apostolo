import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Clock, Phone, ChevronDown } from "lucide-react";
import { CONTACT } from "../data/content";
import { scrollToId } from "../lib/scroll";
import { EASE } from "./Reveal";

const MaskedLine = ({ children, delay, className = "" }) => (
  <span className="block overflow-hidden pb-1">
    <motion.span
      className={`block ${className}`}
      initial={{ y: "110%" }}
      animate={{ y: 0 }}
      transition={{ duration: 1.1, delay, ease: EASE }}
    >
      {children}
    </motion.span>
  </span>
);

export const Hero = () => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const crestY = useTransform(scrollYProgress, [0, 1], [0, 140]);
  const bgY = useTransform(scrollYProgress, [0, 1], [0, -120]);
  const fade = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  return (
    <section id="inicio" ref={ref} data-testid="hero-section" className="relative min-h-screen flex items-center overflow-hidden bg-ink-950">
      <motion.div style={{ y: bgY }} className="absolute inset-0">
        <img
          src="/assets/cruz.png"
          alt=""
          aria-hidden
          className="w-full h-full object-cover object-center opacity-40 scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-ink-950/80 via-crimson-900/55 to-ink-950" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(212,175,55,0.14),transparent_60%)]" />
      </motion.div>

      <motion.div style={{ opacity: fade }} className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 pt-32 pb-24 grid lg:grid-cols-[1.15fr_0.85fr] gap-14 items-center">
        <div>
          <MaskedLine delay={0.5}>
            <span className="inline-flex items-center gap-3 text-gold-400 text-[11px] sm:text-xs font-sans font-bold uppercase tracking-[0.34em]">
              <span className="h-px w-10 bg-gold-500/60" />
              Carapicuíba · Diocese de Osasco
            </span>
          </MaskedLine>

          <h1 className="mt-6 font-serif font-bold text-cream-50 leading-[0.98] tracking-tight text-[13vw] sm:text-7xl lg:text-[5.6rem]">
            <MaskedLine delay={0.62}>Paróquia</MaskedLine>
            <MaskedLine delay={0.74}>
              <span className="italic font-medium text-gold-300">São Paulo</span>
            </MaskedLine>
            <MaskedLine delay={0.86}>Apóstolo</MaskedLine>
          </h1>

          <MaskedLine delay={1.05} className="mt-7 max-w-xl">
            <p className="text-cream-100/80 text-base sm:text-lg leading-relaxed font-sans font-light">
              Uma comunidade acolhedora guiada pela fé. Em nossa caminhada,
              desejamos estar cada vez mais perto de você — nas missas, nas
              celebrações e na vida de cada família.
            </p>
          </MaskedLine>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 1.25, ease: EASE }}
            className="mt-10 flex flex-wrap items-center gap-4"
          >
            <button
              data-testid="hero-mass-times-button"
              onClick={() => scrollToId("missas")}
              className="group inline-flex items-center gap-2.5 rounded-full bg-gold-500 hover:bg-gold-400 text-ink-950 font-bold text-sm uppercase tracking-wide px-7 py-4 transition-all duration-300 hover:shadow-[0_14px_36px_rgba(212,175,55,0.35)] hover:-translate-y-0.5"
            >
              <Clock size={17} className="transition-transform duration-500 group-hover:rotate-12" />
              Horários de Missa
            </button>
            <a
              data-testid="hero-schedule-button"
              href={CONTACT.phoneHref}
              className="inline-flex items-center gap-2.5 rounded-full border border-cream-50/30 hover:border-gold-400 text-cream-50 hover:text-gold-300 font-semibold text-sm uppercase tracking-wide px-7 py-4 transition-all duration-300 hover:-translate-y-0.5 backdrop-blur-sm"
            >
              <Phone size={17} />
              Ligue para Agendar
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.6, duration: 1 }}
            className="mt-12 flex items-center gap-6 text-cream-100/50 text-xs font-sans uppercase tracking-[0.2em]"
          >
            <span>Fundada em 27 · 10 · 2000</span>
            <span className="h-1 w-1 rounded-full bg-gold-500/70" />
            <span>3 Comunidades</span>
          </motion.div>
        </div>

        <motion.div style={{ y: crestY }} className="relative hidden lg:flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.82, rotate: -4 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ duration: 1.4, delay: 0.9, ease: EASE }}
            className="relative"
          >
            <div className="absolute -inset-10 rounded-full bg-gold-500/10 blur-3xl" />
            <div className="halo-ring absolute -inset-6 rounded-full animate-spin-slow" />
            <div className="absolute -inset-6 rounded-full border border-gold-500/25" />
            <img
              src="/assets/brasao.png"
              alt="Brasão da Paróquia São Paulo Apóstolo de Carapicuíba"
              className="relative h-[380px] w-auto drop-shadow-[0_30px_60px_rgba(0,0,0,0.55)]"
            />
          </motion.div>
        </motion.div>
      </motion.div>

      <motion.button
        data-testid="hero-scroll-indicator"
        onClick={() => scrollToId("missas")}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 text-cream-100/60 hover:text-gold-300 transition-colors duration-300"
        aria-label="Rolar para baixo"
      >
        <motion.div animate={{ y: [0, 10, 0] }} transition={{ repeat: Infinity, duration: 2.2, ease: "easeInOut" }}>
          <ChevronDown size={28} />
        </motion.div>
      </motion.button>
    </section>
  );
};
