import { useEffect, useRef, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Play, Youtube, Instagram } from "lucide-react";
import { CONTACT } from "../data/content";
import api from "../lib/api";
import { Reveal, SectionHeading, EASE } from "./Reveal";

export const WebTV = () => {
  const ref = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [video, setVideo] = useState(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const imgY = useTransform(scrollYProgress, [0, 1], [60, -60]);

  useEffect(() => {
    api.get("/webtv").then((r) => {
      if (r.data && r.data.videoId) setVideo(r.data);
    }).catch(() => {});
  }, []);

  const handlePlay = () => {
    if (video && video.videoId) {
      setPlaying(true);
    } else {
      window.open(CONTACT.youtube, "_blank", "noopener,noreferrer");
    }
  };

  return (
    <section id="aovivo" ref={ref} data-testid="webtv-live-section" className="relative py-24 sm:py-32 bg-crimson-900 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(212,175,55,0.16),transparent_55%)]" />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 grid lg:grid-cols-2 gap-14 items-center">
        <div>
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-2 rounded-full bg-crimson-700 border border-gold-500/30 text-cream-50 text-[11px] font-bold uppercase tracking-[0.2em] px-4 py-2">
              <span className={`h-2 w-2 rounded-full ${video?.live ? "bg-red-500 animate-pulse-dot" : "bg-gold-400 animate-pulse-dot"}`} />
              {video?.live ? "Ao vivo agora" : "Transmissão ao vivo"}
            </span>
          </div>
          <div className="mt-6">
            <SectionHeading dark kicker="WebTV PSPA" title={<>Assista à missa<br />de onde estiver</>} />
          </div>
          <Reveal delay={0.2}>
            <p className="mt-6 text-cream-100/70 text-base sm:text-lg leading-relaxed max-w-lg">
              Todos os domingos às 19h, a Santa Missa da Matriz é transmitida ao
              vivo pelo nosso canal no YouTube. Inscreva-se e participe com a
              sua família.
            </p>
          </Reveal>
          <Reveal delay={0.3}>
            <div className="mt-9 flex flex-wrap gap-4">
              <a
                data-testid="webtv-watch-live-button"
                href={CONTACT.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="group inline-flex items-center gap-3 rounded-full bg-gold-500 hover:bg-gold-400 text-ink-950 font-bold text-sm uppercase tracking-wide px-8 py-4 transition-all duration-300 hover:shadow-[0_16px_40px_rgba(212,175,55,0.35)] hover:-translate-y-0.5"
              >
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-ink-950 text-gold-400 transition-transform duration-500 group-hover:scale-110">
                  <Play size={12} fill="currentColor" />
                </span>
                Assistir ao Vivo
              </a>
              <a
                data-testid="webtv-instagram-button"
                href={CONTACT.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2.5 rounded-full border border-cream-50/25 hover:border-gold-400 text-cream-50 hover:text-gold-300 font-semibold text-sm uppercase tracking-wide px-7 py-4 transition-all duration-300"
              >
                <Instagram size={17} />
                @pspacarapicuiba
              </a>
            </div>
          </Reveal>
          <Reveal delay={0.4}>
            <p className="mt-8 flex items-center gap-2 text-cream-100/45 text-sm font-sans">
              <Youtube size={16} className="text-gold-500" />
              youtube.com/webtvpspa — celebrações, novenas e momentos especiais
            </p>
          </Reveal>
        </div>

        <motion.div style={{ y: imgY }} className="relative">
          <motion.div
            initial={{ opacity: 0, scale: 0.94, rotate: 2 }}
            whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 1, ease: EASE }}
            className="relative rounded-3xl overflow-hidden border border-gold-500/30 shadow-[0_30px_80px_rgba(0,0,0,0.5)]"
          >
            {playing && video ? (
              <iframe
                data-testid="webtv-live-iframe"
                src={`https://www.youtube-nocookie.com/embed/${video.videoId}?autoplay=1&rel=0`}
                title="WebTV PSPA — Transmissão"
                className="w-full h-[320px] sm:h-[420px]"
                referrerPolicy="strict-origin-when-cross-origin"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            ) : (
              <>
                <img src="/assets/missa3.png" alt="Celebração na Paróquia São Paulo Apóstolo" className="w-full h-[320px] sm:h-[420px] object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-crimson-900/85 via-transparent to-transparent" />
                <button
                  data-testid="webtv-thumbnail-play"
                  onClick={handlePlay}
                  aria-label="Tocar transmissão da WebTV PSPA"
                  className="absolute inset-0 flex items-center justify-center group cursor-pointer"
                >
                  <span className="flex h-20 w-20 items-center justify-center rounded-full bg-gold-500 text-ink-950 shadow-[0_0_0_12px_rgba(212,175,55,0.2)] transition-all duration-500 group-hover:scale-110 group-hover:shadow-[0_0_0_20px_rgba(212,175,55,0.15)]">
                    <Play size={30} fill="currentColor" className="ml-1" />
                  </span>
                </button>
              </>
            )}
            {!playing && (
              <div className="absolute bottom-5 left-5 right-5 flex items-center justify-between pointer-events-none">
                <p className="font-serif italic text-cream-50 text-lg">{video && !video.live ? "Última celebração" : "Domingos · 19h00"}</p>
                <span className="rounded-full bg-ink-950/70 backdrop-blur px-3.5 py-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-gold-300">
                  WebTV PSPA
                </span>
              </div>
            )}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};
