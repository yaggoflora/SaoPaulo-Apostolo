import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Youtube } from "lucide-react";
import { NAV_LINKS, CONTACT } from "../data/content";
import { scrollToId } from "../lib/scroll";

export const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (id) => {
    setOpen(false);
    setTimeout(() => scrollToId(id), open ? 250 : 0);
  };

  return (
    <motion.header
      data-testid="nav-header"
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.9, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
      className={`fixed top-0 left-0 right-0 z-50 transition-[background-color,box-shadow,border-color] duration-500 ${
        scrolled
          ? "bg-cream-50/85 backdrop-blur-xl border-b border-gold-500/20 shadow-[0_8px_30px_rgba(90,0,18,0.08)]"
          : "bg-transparent border-b border-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 h-[72px] flex items-center justify-between">
        <button
          data-testid="nav-logo-button"
          onClick={() => go("inicio")}
          className="flex items-center gap-3 group"
        >
          <img src="/assets/brasao.png" alt="Brasão da Paróquia São Paulo Apóstolo" className="h-11 w-auto drop-shadow-sm transition-transform duration-500 group-hover:scale-110" />
          <div className="text-left leading-tight hidden sm:block">
            <p className={`font-display text-[13px] tracking-[0.14em] font-semibold transition-colors duration-500 ${scrolled ? "text-crimson-800" : "text-cream-50"}`}>
              PARÓQUIA
            </p>
            <p className={`font-serif italic text-sm transition-colors duration-500 ${scrolled ? "text-ink-600" : "text-gold-300"}`}>
              São Paulo Apóstolo
            </p>
          </div>
        </button>

        <nav className="hidden lg:flex items-center gap-7" aria-label="Navegação principal">
          {NAV_LINKS.filter((l) => l.id !== "inicio").map((link) => (
            <button
              key={link.id}
              data-testid={`nav-link-${link.id}`}
              onClick={() => go(link.id)}
              className={`gold-underline text-[13px] font-sans font-semibold tracking-wide uppercase transition-colors duration-500 ${
                scrolled ? "text-ink-800 hover:text-crimson-700" : "text-cream-100/90 hover:text-gold-300"
              }`}
            >
              {link.label}
            </button>
          ))}
          <a
            data-testid="nav-live-button"
            href={CONTACT.youtube}
            target="_blank"
            rel="noopener noreferrer"
            className="ml-2 inline-flex items-center gap-2 rounded-full bg-crimson-700 hover:bg-crimson-600 text-cream-50 text-[13px] font-bold uppercase tracking-wide px-5 py-2.5 transition-all duration-300 hover:shadow-[0_10px_28px_rgba(139,0,29,0.4)] hover:-translate-y-0.5"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-pulse-dot absolute inline-flex h-full w-full rounded-full bg-gold-400" />
            </span>
            Ao Vivo
          </a>
        </nav>

        <button
          data-testid="nav-mobile-menu-button"
          onClick={() => setOpen(!open)}
          aria-label="Abrir menu"
          className={`lg:hidden p-2 rounded-full transition-colors duration-500 ${scrolled ? "text-ink-900" : "text-cream-50"}`}
        >
          {open ? <X size={26} /> : <Menu size={26} />}
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.nav
            data-testid="nav-mobile-menu"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className="lg:hidden overflow-hidden bg-ink-950/95 backdrop-blur-xl border-t border-gold-500/15"
          >
            <div className="px-6 py-6 flex flex-col gap-1">
              {NAV_LINKS.map((link, i) => (
                <motion.button
                  key={link.id}
                  data-testid={`nav-mobile-link-${link.id}`}
                  initial={{ opacity: 0, x: -18 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 * i, duration: 0.35 }}
                  onClick={() => go(link.id)}
                  className="text-left font-serif text-2xl text-cream-100 py-2.5 border-b border-cream-50/5 hover:text-gold-300 transition-colors duration-300"
                >
                  {link.label}
                </motion.button>
              ))}
              <motion.a
                data-testid="nav-mobile-live-button"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                href={CONTACT.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-5 inline-flex items-center justify-center gap-2 rounded-full bg-crimson-700 text-cream-50 font-bold uppercase tracking-wide text-sm px-6 py-3.5"
              >
                <Youtube size={18} />
                Assistir ao Vivo
              </motion.a>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </motion.header>
  );
};
