import { motion } from "framer-motion";
import { ArrowRight, Phone } from "lucide-react";
import { SACRAMENTOS, CONTACT } from "../data/content";
import { Reveal, SectionHeading, EASE } from "./Reveal";

export const Sacraments = () => (
  <section id="sacramentos" data-testid="sacraments-section" className="relative py-24 sm:py-32 bg-cream-50 overflow-hidden">
    <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
      <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8">
        <SectionHeading kicker="Sacramentos" title={<>Sinais visíveis<br />da graça de Deus</>} />
        <Reveal delay={0.2} className="max-w-md">
          <p className="text-ink-600 text-base sm:text-lg leading-relaxed lg:text-right">
            Para agendar batismo, casamento, confissão e outros assuntos, fale
            com a nossa secretaria. Será uma alegria acolher você.
          </p>
        </Reveal>
      </div>

      <div className="mt-16 border-t border-cream-300">
        {SACRAMENTOS.map((s, i) => (
          <motion.div
            key={s.num}
            data-testid={`sacrament-row-${i}`}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.7, delay: 0.04 * i, ease: EASE }}
            className="group grid grid-cols-[auto_1fr] sm:grid-cols-[auto_1fr_auto] items-start sm:items-center gap-x-6 sm:gap-x-10 gap-y-2 border-b border-cream-300 py-7 sm:py-8 hover:bg-gold-100/40 transition-colors duration-500 px-2 sm:px-4 rounded-lg"
          >
            <span className="font-display text-gold-600/70 group-hover:text-crimson-700 text-2xl sm:text-4xl font-semibold transition-colors duration-500 pt-1">
              {s.num}
            </span>
            <div>
              <h3 className="font-serif font-bold text-2xl sm:text-3xl text-ink-900 tracking-tight">
                {s.name}
                <span className="block sm:inline sm:ml-4 font-serif italic font-medium text-base sm:text-lg text-gold-700">
                  {s.verse}
                </span>
              </h3>
              <p className="mt-2 max-w-2xl text-sm sm:text-base text-ink-600 leading-relaxed">{s.desc}</p>
            </div>
            <ArrowRight
              size={22}
              className="hidden sm:block text-cream-300 group-hover:text-crimson-700 group-hover:translate-x-1.5 transition-all duration-500"
            />
          </motion.div>
        ))}
      </div>

      <Reveal delay={0.15}>
        <div className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            data-testid="sacraments-call-button"
            href={CONTACT.phoneHref}
            className="inline-flex items-center gap-2.5 rounded-full bg-crimson-700 hover:bg-crimson-600 text-cream-50 font-bold text-sm uppercase tracking-wide px-8 py-4 transition-all duration-300 hover:shadow-[0_14px_36px_rgba(139,0,29,0.35)] hover:-translate-y-0.5"
          >
            <Phone size={17} />
            Ligue para Agendar
          </a>
          <p className="text-sm text-ink-600">
            Secretaria paroquial · {CONTACT.phoneDisplay}
          </p>
        </div>
      </Reveal>
    </div>
  </section>
);
