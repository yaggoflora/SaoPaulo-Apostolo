import { motion } from "framer-motion";
import { MapPin, Phone, Mail, MessageCircle, Instagram, Youtube, Facebook } from "lucide-react";
import { CONTACT } from "../data/content";
import { Reveal, SectionHeading, EASE } from "./Reveal";

const CARDS = [
  { icon: MapPin, label: "Endereço", value: "R. Rio Branco, 38 — Castelo Branco, Carapicuíba – SP", href: CONTACT.mapsUrl, testid: "contact-address-link" },
  { icon: Phone, label: "Secretaria", value: CONTACT.phoneDisplay, href: CONTACT.phoneHref, testid: "contact-phone-link" },
  { icon: Mail, label: "E-mail", value: CONTACT.email, href: `mailto:${CONTACT.email}`, testid: "contact-email-link" },
];

export const Contact = () => (
  <section id="contato" data-testid="contact-location-section" className="relative py-24 sm:py-32 bg-cream-50 overflow-hidden">
    <div className="absolute top-0 left-1/2 w-[700px] h-[400px] rounded-full bg-gold-100 blur-3xl opacity-50 -translate-x-1/2 -translate-y-1/2" />
    <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
      <div className="text-center max-w-2xl mx-auto">
        <SectionHeading align="center" kicker="Contato e Localização" title={<>Venha nos visitar</>} />
        <Reveal delay={0.2}>
          <p className="mt-6 text-ink-600 text-base sm:text-lg leading-relaxed">
            A secretaria paroquial atende agendamentos de batismo, casamento,
            confissão e demais assuntos. Estamos de portas abertas para você.
          </p>
        </Reveal>
      </div>

      <div className="mt-14 grid lg:grid-cols-[0.9fr_1.1fr] gap-8 items-stretch">
        <div className="flex flex-col gap-4">
          {CARDS.map((c, i) => (
            <motion.a
              key={c.label}
              data-testid={c.testid}
              href={c.href}
              target={c.href.startsWith("http") ? "_blank" : undefined}
              rel={c.href.startsWith("http") ? "noopener noreferrer" : undefined}
              initial={{ opacity: 0, y: 26 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.7, delay: 0.08 * i, ease: EASE }}
              whileHover={{ x: 6 }}
              className="group flex items-center gap-5 rounded-2xl border border-cream-200 bg-white p-6 shadow-[0_4px_18px_rgba(90,0,18,0.05)] hover:shadow-[0_16px_40px_rgba(90,0,18,0.12)] hover:border-gold-500/40 transition-[box-shadow,border-color] duration-400"
            >
              <span className="flex h-13 w-13 shrink-0 items-center justify-center rounded-xl bg-crimson-100 p-3.5 text-crimson-700 group-hover:bg-crimson-700 group-hover:text-gold-300 transition-colors duration-400">
                <c.icon size={22} />
              </span>
              <div>
                <p className="text-[11px] font-sans font-bold uppercase tracking-[0.22em] text-gold-700">{c.label}</p>
                <p className="mt-1 font-serif font-semibold text-lg text-ink-900 leading-snug">{c.value}</p>
              </div>
            </motion.a>
          ))}

          <Reveal delay={0.3}>
            <div className="flex flex-wrap gap-3 mt-2">
              <a
                data-testid="contact-whatsapp-button"
                href={CONTACT.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 min-w-[160px] inline-flex items-center justify-center gap-2.5 rounded-full bg-crimson-700 hover:bg-crimson-600 text-cream-50 font-bold text-sm uppercase tracking-wide px-6 py-4 transition-all duration-300 hover:shadow-[0_14px_36px_rgba(139,0,29,0.35)] hover:-translate-y-0.5"
              >
                <MessageCircle size={18} />
                WhatsApp
              </a>
              <a
                data-testid="contact-instagram-button"
                href={CONTACT.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 rounded-full border border-cream-300 hover:border-crimson-700 text-ink-800 hover:text-crimson-700 font-semibold text-sm px-6 py-4 transition-colors duration-300"
              >
                <Instagram size={18} />
                Instagram
              </a>
              <a
                data-testid="contact-youtube-button"
                href={CONTACT.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 rounded-full border border-cream-300 hover:border-crimson-700 text-ink-800 hover:text-crimson-700 font-semibold text-sm px-6 py-4 transition-colors duration-300"
              >
                <Youtube size={18} />
                YouTube
              </a>
            </div>
          </Reveal>
        </div>

        <Reveal delay={0.2} className="h-full">
          <div className="relative h-full min-h-[340px] rounded-3xl overflow-hidden border border-cream-200 shadow-[0_20px_50px_rgba(90,0,18,0.1)]">
            <iframe
              data-testid="contact-map-iframe"
              title="Mapa da Paróquia São Paulo Apóstolo"
              src={CONTACT.mapsEmbed}
              className="absolute inset-0 h-full w-full"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              allowFullScreen
            />
          </div>
        </Reveal>
      </div>
    </div>
  </section>
);

export const Footer = () => (
  <footer data-testid="site-footer" className="relative bg-ink-950 border-t border-gold-500/15 pt-16 pb-8 overflow-hidden">
    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,rgba(139,0,29,0.25),transparent_60%)]" />
    <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
      <div className="flex flex-col md:flex-row items-center md:items-start justify-between gap-10">
        <div className="flex items-center gap-4">
          <img src="/assets/brasao.png" alt="Brasão da paróquia" className="h-16 w-auto" />
          <div>
            <p className="font-display text-cream-50 tracking-[0.14em] font-semibold text-sm">PARÓQUIA SÃO PAULO APÓSTOLO</p>
            <p className="font-serif italic text-gold-400 text-sm mt-0.5">Carapicuíba — SP · Diocese de Osasco</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          {[
            { icon: Instagram, href: CONTACT.instagram, testid: "footer-instagram-link", label: "Instagram" },
            { icon: Youtube, href: CONTACT.youtube, testid: "footer-youtube-link", label: "YouTube" },
            { icon: Facebook, href: CONTACT.facebook, testid: "footer-facebook-link", label: "Facebook" },
          ].map((s) => (
            <a
              key={s.testid}
              data-testid={s.testid}
              href={s.href}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={s.label}
              className="flex h-11 w-11 items-center justify-center rounded-full border border-cream-50/15 text-cream-100/70 hover:text-gold-300 hover:border-gold-400/60 hover:-translate-y-1 transition-all duration-300"
            >
              <s.icon size={18} />
            </a>
          ))}
        </div>
      </div>
      <div className="mt-10 border-t border-cream-50/8 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-cream-100/40 font-sans">
        <p>R. Rio Branco, 38 — Castelo Branco, Carapicuíba – SP · {CONTACT.phoneDisplay} · {CONTACT.email}</p>
        <p className="font-serif italic text-gold-500/70">“Fundador de comunidades, coluna da Igreja.”</p>
      </div>
    </div>
  </footer>
);
