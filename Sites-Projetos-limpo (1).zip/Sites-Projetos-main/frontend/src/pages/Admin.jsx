import { useCallback, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { LogOut, Plus, Trash2, Pencil, RefreshCw, Megaphone, CalendarCheck, X } from "lucide-react";
import api, { formatApiError } from "../lib/api";

const EMPTY_AVISO = { titulo: "", tag: "Aviso", data: "", texto: "" };

const inputCls = "w-full rounded-xl border border-cream-200 bg-white px-4 py-3 text-sm text-ink-900 placeholder:text-ink-600/40 outline-none focus:border-crimson-600 focus:ring-2 focus:ring-crimson-600/15 transition-all duration-300";

function Login({ onSuccess }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const { data } = await api.post("/auth/login", { email, password });
      onSuccess(data);
    } catch (err) {
      setError(formatApiError(err.response?.data?.detail));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-ink-950 flex items-center justify-center px-4">
      <motion.form
        data-testid="admin-login-form"
        onSubmit={submit}
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="w-full max-w-md rounded-3xl bg-cream-50 p-8 sm:p-10 shadow-2xl"
      >
        <div className="flex flex-col items-center text-center">
          <img src="/assets/brasao.png" alt="Brasão da paróquia" className="h-20 w-auto" />
          <h1 className="mt-4 font-serif font-bold text-2xl text-ink-900">Área da Secretaria</h1>
          <p className="mt-1 text-sm text-ink-600">Acesso restrito para edição de avisos</p>
        </div>
        <div className="mt-8 flex flex-col gap-4">
          <input data-testid="admin-email-input" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="E-mail" className={inputCls} />
          <input data-testid="admin-password-input" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Senha" className={inputCls} />
          {error && <p data-testid="admin-login-error" className="text-sm text-crimson-600 font-semibold">{error}</p>}
          <button
            data-testid="admin-login-submit"
            type="submit"
            disabled={loading}
            className="rounded-full bg-crimson-700 hover:bg-crimson-600 text-cream-50 font-bold text-sm uppercase tracking-wide px-8 py-4 transition-colors duration-300 disabled:opacity-60"
          >
            {loading ? "Entrando..." : "Entrar"}
          </button>
          <a href="/" className="text-center text-xs text-ink-600/60 hover:text-crimson-700 transition-colors">Voltar ao site</a>
        </div>
      </motion.form>
    </div>
  );
}

export default function Admin() {
  const [user, setUser] = useState(null);
  const [tab, setTab] = useState("avisos");
  const [avisos, setAvisos] = useState([]);
  const [agendamentos, setAgendamentos] = useState([]);
  const [form, setForm] = useState(EMPTY_AVISO);
  const [editingId, setEditingId] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get("/auth/me").then((r) => setUser(r.data)).catch(() => setUser(false));
  }, []);

  const loadAvisos = useCallback(() => {
    api.get("/avisos").then((r) => setAvisos(r.data)).catch(() => {});
  }, []);

  const loadAgendamentos = useCallback(() => {
    api.get("/agendamentos").then((r) => setAgendamentos(r.data)).catch((e) => {
      if (e.response?.status === 401) setUser(false);
    });
  }, []);

  useEffect(() => {
    if (user) { loadAvisos(); loadAgendamentos(); }
  }, [user, loadAvisos, loadAgendamentos]);

  const logout = async () => {
    await api.post("/auth/logout").catch(() => {});
    setUser(false);
  };

  const saveAviso = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingId) {
        await api.put(`/avisos/${editingId}`, form);
        toast.success("Aviso atualizado");
      } else {
        await api.post("/avisos", form);
        toast.success("Aviso publicado");
      }
      setForm(EMPTY_AVISO);
      setEditingId(null);
      loadAvisos();
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail));
    } finally {
      setSaving(false);
    }
  };

  const removeAviso = async (id) => {
    try {
      await api.delete(`/avisos/${id}`);
      toast.success("Aviso removido");
      loadAvisos();
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail));
    }
  };

  if (user === null) {
    return <div className="min-h-screen bg-ink-950 flex items-center justify-center"><p className="text-cream-100/60 font-serif italic text-xl">Carregando...</p></div>;
  }
  if (user === false) {
    return <Login onSuccess={setUser} />;
  }

  return (
    <div data-testid="admin-dashboard" className="min-h-screen bg-cream-50">
      <header className="bg-ink-950 border-b border-gold-500/15">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-[68px] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/assets/brasao.png" alt="Brasão" className="h-10 w-auto" />
            <div>
              <p className="font-display text-cream-50 text-xs tracking-[0.16em] font-semibold">SECRETARIA PSPA</p>
              <p className="text-[11px] text-gold-400/80">{user.email}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a href="/" className="text-cream-100/60 hover:text-gold-300 text-xs font-semibold uppercase tracking-wide px-3 py-2 transition-colors">Ver site</a>
            <button data-testid="admin-logout-button" onClick={logout} className="inline-flex items-center gap-2 rounded-full border border-cream-50/20 hover:border-gold-400 text-cream-50 hover:text-gold-300 text-xs font-bold uppercase tracking-wide px-4 py-2.5 transition-colors">
              <LogOut size={14} />
              Sair
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-10">
        <div className="inline-flex rounded-full border border-cream-300 bg-white p-1.5 shadow-sm">
          {[
            { key: "avisos", label: "Avisos", icon: Megaphone },
            { key: "agendamentos", label: "Agendamentos", icon: CalendarCheck },
          ].map((t) => (
            <button
              key={t.key}
              data-testid={`admin-tab-${t.key}`}
              onClick={() => setTab(t.key)}
              className={`inline-flex items-center gap-2 rounded-full px-6 py-2.5 text-sm font-bold uppercase tracking-wide transition-colors duration-300 ${tab === t.key ? "bg-crimson-700 text-cream-50" : "text-ink-600 hover:text-crimson-700"}`}
            >
              <t.icon size={15} />
              {t.label}
            </button>
          ))}
        </div>

        {tab === "avisos" && (
          <div className="mt-8 grid lg:grid-cols-[0.9fr_1.1fr] gap-8 items-start">
            <form data-testid="admin-aviso-form" onSubmit={saveAviso} className="rounded-2xl border border-cream-200 bg-white p-6 shadow-sm">
              <h2 className="font-serif font-bold text-xl text-ink-900">{editingId ? "Editar aviso" : "Novo aviso"}</h2>
              <div className="mt-5 flex flex-col gap-3.5">
                <input data-testid="admin-aviso-titulo" required minLength={2} value={form.titulo} onChange={(e) => setForm({ ...form, titulo: e.target.value })} placeholder="Título do aviso" className={inputCls} />
                <div className="grid grid-cols-2 gap-3.5">
                  <select data-testid="admin-aviso-tag" value={form.tag} onChange={(e) => setForm({ ...form, tag: e.target.value })} className={inputCls}>
                    {["Aviso", "Festa", "Transmissão", "Formação", "Urgente"].map((t) => <option key={t}>{t}</option>)}
                  </select>
                  <input data-testid="admin-aviso-data" value={form.data} onChange={(e) => setForm({ ...form, data: e.target.value })} placeholder="Ex.: Dom · 19h" className={inputCls} />
                </div>
                <textarea data-testid="admin-aviso-texto" required minLength={2} rows={4} value={form.texto} onChange={(e) => setForm({ ...form, texto: e.target.value })} placeholder="Texto do aviso" className={`${inputCls} resize-none`} />
                <div className="flex gap-3">
                  <button data-testid="admin-aviso-save" type="submit" disabled={saving} className="flex-1 inline-flex items-center justify-center gap-2 rounded-full bg-crimson-700 hover:bg-crimson-600 text-cream-50 font-bold text-sm uppercase tracking-wide px-6 py-3.5 transition-colors disabled:opacity-60">
                    <Plus size={16} />
                    {saving ? "Salvando..." : editingId ? "Salvar alterações" : "Publicar aviso"}
                  </button>
                  {editingId && (
                    <button data-testid="admin-aviso-cancel" type="button" onClick={() => { setEditingId(null); setForm(EMPTY_AVISO); }} className="inline-flex items-center gap-2 rounded-full border border-cream-300 text-ink-800 text-sm font-semibold px-5 py-3.5 hover:border-crimson-700 transition-colors">
                      <X size={15} />
                      Cancelar
                    </button>
                  )}
                </div>
              </div>
            </form>

            <div className="flex flex-col gap-3.5">
              {avisos.length === 0 && <p className="text-sm text-ink-600/60 italic">Nenhum aviso publicado.</p>}
              {avisos.map((a, i) => (
                <div key={a.id} data-testid={`admin-aviso-item-${i}`} className="flex items-start justify-between gap-4 rounded-2xl border border-cream-200 bg-white p-5 shadow-sm">
                  <div>
                    <div className="flex items-center gap-2.5">
                      <span className="rounded-full bg-crimson-100 text-crimson-700 text-[10px] font-bold uppercase tracking-[0.14em] px-2.5 py-1">{a.tag}</span>
                      {a.data && <span className="text-xs font-semibold text-gold-700">{a.data}</span>}
                    </div>
                    <h3 className="mt-2 font-serif font-bold text-lg text-ink-900">{a.titulo}</h3>
                    <p className="mt-1 text-sm text-ink-600 leading-relaxed">{a.texto}</p>
                  </div>
                  <div className="flex shrink-0 gap-2">
                    <button data-testid={`admin-aviso-edit-${i}`} onClick={() => { setEditingId(a.id); setForm({ titulo: a.titulo, tag: a.tag, data: a.data, texto: a.texto }); }} aria-label="Editar aviso" className="flex h-9 w-9 items-center justify-center rounded-full border border-cream-300 text-ink-800 hover:border-gold-600 hover:text-gold-700 transition-colors">
                      <Pencil size={15} />
                    </button>
                    <button data-testid={`admin-aviso-delete-${i}`} onClick={() => removeAviso(a.id)} aria-label="Excluir aviso" className="flex h-9 w-9 items-center justify-center rounded-full border border-cream-300 text-ink-800 hover:border-crimson-600 hover:text-crimson-600 transition-colors">
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "agendamentos" && (
          <div className="mt-8">
            <div className="flex items-center justify-between">
              <h2 className="font-serif font-bold text-2xl text-ink-900">Pedidos recebidos</h2>
              <button data-testid="admin-agendamentos-refresh" onClick={loadAgendamentos} className="inline-flex items-center gap-2 rounded-full border border-cream-300 text-ink-800 text-xs font-bold uppercase tracking-wide px-4 py-2.5 hover:border-crimson-700 hover:text-crimson-700 transition-colors">
                <RefreshCw size={14} />
                Atualizar
              </button>
            </div>
            <div className="mt-5 grid sm:grid-cols-2 gap-4">
              {agendamentos.length === 0 && <p className="text-sm text-ink-600/60 italic">Nenhum pedido por enquanto.</p>}
              {agendamentos.map((a, i) => (
                <div key={a.id} data-testid={`admin-agendamento-item-${i}`} className="rounded-2xl border border-cream-200 bg-white p-5 shadow-sm">
                  <div className="flex items-center justify-between">
                    <span className="rounded-full bg-gold-100 text-gold-800 text-[10px] font-bold uppercase tracking-[0.14em] px-2.5 py-1">{a.tipo}</span>
                    <span className="text-[11px] text-ink-600/50">{a.created_at ? new Date(a.created_at).toLocaleString("pt-BR") : ""}</span>
                  </div>
                  <h3 className="mt-2.5 font-serif font-bold text-lg text-ink-900">{a.nome}</h3>
                  <p className="text-sm text-ink-600 mt-1">{a.telefone}{a.email ? ` · ${a.email}` : ""}</p>
                  {a.data_preferida && <p className="text-sm text-gold-700 font-semibold mt-1">Data preferida: {a.data_preferida}</p>}
                  {a.mensagem && <p className="mt-2 text-sm text-ink-600 leading-relaxed border-t border-cream-200 pt-2">{a.mensagem}</p>}
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
