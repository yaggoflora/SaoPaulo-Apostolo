from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

import os
import re
import uuid
import asyncio
import ipaddress
import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from html import escape
from html.parser import HTMLParser
from urllib.parse import urlparse
from datetime import datetime, timezone, timedelta
from typing import List, Optional

import bcrypt
import jwt
import httpx
from fastapi import FastAPI, APIRouter, HTTPException, Request, Response, Depends
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field, EmailStr

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

app = FastAPI()
api_router = APIRouter(prefix="/api")

JWT_ALGORITHM = "HS256"

# Configuração de e-mail via SMTP (Gmail, Zoho, SendGrid SMTP, etc.)
SMTP_HOST = os.environ.get("SMTP_HOST", "")
SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
SMTP_USER = os.environ.get("SMTP_USER", "")
SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD", "")
EMAIL_FROM_NAME = os.environ.get("EMAIL_FROM_NAME", "Paróquia São Paulo Apóstolo")
EMAIL_REPLY_TO = os.environ.get("EMAIL_REPLY_TO")
SECRETARY_EMAIL = os.environ.get("SECRETARY_EMAIL", "secretaria@pspa.com.br")


# ---------------- Auth ----------------

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return bcrypt.checkpw(plain_password.encode("utf-8"), hashed_password.encode("utf-8"))

def get_jwt_secret() -> str:
    return os.environ["JWT_SECRET"]

def create_access_token(user_id: str, email: str) -> str:
    payload = {"sub": user_id, "email": email, "exp": datetime.now(timezone.utc) + timedelta(minutes=60), "type": "access"}
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)

def create_refresh_token(user_id: str) -> str:
    payload = {"sub": user_id, "exp": datetime.now(timezone.utc) + timedelta(days=7), "type": "refresh"}
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)

async def get_current_user(request: Request) -> dict:
    token = request.cookies.get("access_token")
    if not token:
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
    if not token:
        raise HTTPException(status_code=401, detail="Não autenticado")
    try:
        payload = jwt.decode(token, get_jwt_secret(), algorithms=[JWT_ALGORITHM])
        if payload.get("type") != "access":
            raise HTTPException(status_code=401, detail="Token inválido")
        user = await db.users.find_one({"email": payload["email"]})
        if not user:
            raise HTTPException(status_code=401, detail="Usuário não encontrado")
        user["_id"] = str(user["_id"])
        user.pop("password_hash", None)
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Sessão expirada")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Token inválido")

class LoginInput(BaseModel):
    email: EmailStr
    password: str

@api_router.post("/auth/login")
async def login(input: LoginInput, request: Request, response: Response):
    email = input.email.lower()
    identifier = f"{request.client.host}:{email}"
    attempts = await db.login_attempts.find_one({"identifier": identifier})
    if attempts and attempts.get("count", 0) >= 5:
        locked_until = attempts.get("locked_until")
        if locked_until and datetime.fromisoformat(locked_until) > datetime.now(timezone.utc):
            raise HTTPException(status_code=429, detail="Muitas tentativas. Tente novamente em 15 minutos.")
    user = await db.users.find_one({"email": email})
    if not user or not verify_password(input.password, user["password_hash"]):
        await db.login_attempts.update_one(
            {"identifier": identifier},
            {"$inc": {"count": 1}, "$set": {"locked_until": (datetime.now(timezone.utc) + timedelta(minutes=15)).isoformat()}},
            upsert=True,
        )
        raise HTTPException(status_code=401, detail="E-mail ou senha incorretos")
    await db.login_attempts.delete_one({"identifier": identifier})
    user_id = str(user["_id"])
    response.set_cookie(key="access_token", value=create_access_token(user_id, email), httponly=True, secure=True, samesite="none", max_age=3600, path="/")
    response.set_cookie(key="refresh_token", value=create_refresh_token(user_id), httponly=True, secure=True, samesite="none", max_age=604800, path="/")
    return {"email": email, "name": user.get("name", "Admin"), "role": user.get("role", "admin")}

@api_router.post("/auth/logout")
async def logout(response: Response):
    response.delete_cookie("access_token", path="/")
    response.delete_cookie("refresh_token", path="/")
    return {"status": "ok"}

@api_router.get("/auth/me")
async def me(user=Depends(get_current_user)):
    return {"email": user["email"], "name": user.get("name", "Admin"), "role": user.get("role", "admin")}

@api_router.post("/auth/refresh")
async def refresh(request: Request, response: Response):
    token = request.cookies.get("refresh_token")
    if not token:
        raise HTTPException(status_code=401, detail="Não autenticado")
    try:
        payload = jwt.decode(token, get_jwt_secret(), algorithms=[JWT_ALGORITHM])
        if payload.get("type") != "refresh":
            raise HTTPException(status_code=401, detail="Token inválido")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Token inválido")
    user = await db.users.find_one({"_id": payload["sub"]})
    if not user:
        user = await db.users.find_one({})
    if not user:
        raise HTTPException(status_code=401, detail="Usuário não encontrado")
    response.set_cookie(key="access_token", value=create_access_token(str(user["_id"]), user["email"]), httponly=True, secure=True, samesite="none", max_age=3600, path="/")
    return {"status": "ok"}


# ---------------- Avisos ----------------

class AvisoIn(BaseModel):
    titulo: str = Field(min_length=2, max_length=120)
    texto: str = Field(min_length=2, max_length=600)
    data: str = Field(default="", max_length=60)
    tag: str = Field(default="Aviso", max_length=30)

DEFAULT_AVISOS = [
    {"titulo": "Missa transmitida ao vivo", "data": "Todo domingo · 19h", "tag": "Transmissão",
     "texto": "Santa Missa da Matriz transmitida ao vivo pela WebTV PSPA no YouTube. Reze conosco de onde estiver."},
    {"titulo": "Dozenário de São Benedito", "data": "26/09 a 07/10 · 20h", "tag": "Festa",
     "texto": "Celebrações em honra a São Benedito na Comunidade São Benedito. Participe com sua família."},
    {"titulo": "Solenidade de Nossa Senhora Aparecida", "data": "12/10 · 9h", "tag": "Festa",
     "texto": "Celebração solene da padroeira do Brasil na Matriz São Paulo Apóstolo."},
]

@api_router.get("/avisos")
async def list_avisos():
    return await db.avisos.find({}, {"_id": 0}).sort("created_at", -1).to_list(50)

@api_router.post("/avisos")
async def create_aviso(input: AvisoIn, user=Depends(get_current_user)):
    doc = {"id": str(uuid.uuid4()), **input.model_dump(), "created_at": datetime.now(timezone.utc).isoformat()}
    await db.avisos.insert_one(doc)
    doc.pop("_id", None)
    return doc

@api_router.put("/avisos/{aviso_id}")
async def update_aviso(aviso_id: str, input: AvisoIn, user=Depends(get_current_user)):
    result = await db.avisos.update_one({"id": aviso_id}, {"$set": input.model_dump()})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Aviso não encontrado")
    return {"id": aviso_id, **input.model_dump()}

@api_router.delete("/avisos/{aviso_id}")
async def delete_aviso(aviso_id: str, user=Depends(get_current_user)):
    result = await db.avisos.delete_one({"id": aviso_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Aviso não encontrado")
    return {"status": "ok"}


# ---------------- Email (SMTP) ----------------

_SHORTENERS = ("bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "goo.gl", "rebrand.ly")
_CRED_ASK = ("reply with your password", "reply with the code", "send your password", "cvv",
             "send us your password", "enter your password below", "confirm your card number",
             "your full card number", "seed phrase", "recovery phrase", "verify your card",
             "social security number", "confirm your bank details")
_HOSTISH = re.compile(r"\b(?:https?://)?((?:[a-z0-9-]+\.)+[a-z]{2,})", re.I)

def _host_ok(host: str) -> bool:
    if not host or "xn--" in host:
        return False
    try:
        ipaddress.ip_address(host)
        return False
    except ValueError:
        pass
    return not any(host == s or host.endswith("." + s) for s in _SHORTENERS)

def _same_site(shown: str, real: str) -> bool:
    return shown == real or real.endswith("." + shown) or shown.endswith("." + real)

class _EmailScan(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags, self.urls, self.anchors = set(), [], []
        self._href, self._text = None, []
    def handle_starttag(self, tag, attrs):
        self.tags.add(tag.lower())
        self.urls += [v for k, v in attrs if k.lower() in ("href", "src") and v]
        if tag.lower() == "a":
            self._href = dict((k.lower(), v) for k, v in attrs).get("href")
            self._text = []
    def handle_data(self, data):
        if self._href is not None:
            self._text.append(data)
    def handle_endtag(self, tag):
        if tag.lower() == "a" and self._href is not None:
            self.anchors.append((self._href, "".join(self._text)))
            self._href, self._text = None, []

def _assert_safe_email(subject: str, html: str) -> None:
    scan = _EmailScan(); scan.feed(html)
    if scan.tags & {"form", "input", "textarea", "select"}:
        raise ValueError("No forms or input fields in email (G2)")
    body = f"{subject}\n{html}".lower()
    for p in _CRED_ASK:
        if p in body:
            raise ValueError(f"Email asks the recipient for credentials: {p!r} (G2)")
    for url in scan.urls:
        low = url.strip().lower()
        if low.startswith(("mailto:", "tel:", "cid:", "#")):
            continue
        if not low.startswith("https://"):
            raise ValueError(f"Email links/assets must be absolute https: {url!r} (G3)")
        host = urlparse(low).hostname or ""
        if not _host_ok(host) or urlparse(low).username is not None:
            raise ValueError(f"Shortened, numeric-host or credential-bearing URL: {url!r} (G3)")
    for href, text in scan.anchors:
        real = urlparse(href.strip().lower()).hostname or ""
        if not real:
            continue
        for m in _HOSTISH.finditer(text):
            if not _same_site(m.group(1).lower(), real):
                raise ValueError(f"Anchor text {m.group(1)!r} != real link host {real!r} (G3)")

async def send_email(*, to: str, subject: str, html: str, reply_to: str | None = None) -> bool:
    _assert_safe_email(subject, html)
    if not SMTP_HOST or not SMTP_USER or not SMTP_PASSWORD:
        logger.error("Email not sent: SMTP_HOST/SMTP_USER/SMTP_PASSWORD not configured")
        raise HTTPException(status_code=500, detail="Envio de e-mail não configurado")

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = f"{EMAIL_FROM_NAME} <{SMTP_USER}>"
    msg["To"] = to
    if reply_to or EMAIL_REPLY_TO:
        msg["Reply-To"] = reply_to or EMAIL_REPLY_TO
    msg.attach(MIMEText(html, "html"))

    def _send():
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=30) as smtp:
            smtp.starttls()
            smtp.login(SMTP_USER, SMTP_PASSWORD)
            smtp.sendmail(SMTP_USER, [to], msg.as_string())

    try:
        await asyncio.to_thread(_send)
        return True
    except Exception as e:
        logger.error(f"Email send error: {str(e)}")
        raise HTTPException(status_code=500, detail="Falha ao enviar e-mail")


# ---------------- Agendamentos ----------------

BOOKING_TYPES = {"Batismo", "Casamento", "Confissão", "Outro"}

class AgendamentoIn(BaseModel):
    tipo: str
    nome: str = Field(min_length=2, max_length=120)
    telefone: str = Field(min_length=8, max_length=20)
    email: Optional[EmailStr] = None
    data_preferida: str = Field(default="", max_length=20)
    mensagem: str = Field(default="", max_length=800)

_booking_rate: dict = {}

def _booking_email_html(a: dict) -> str:
    def row(label: str, value: str) -> str:
        return (f'<tr><td style="padding:8px 14px;border:1px solid #E8DEC9;color:#8B001D;'
                f'font-weight:bold;font-family:Arial,sans-serif;font-size:14px">{escape(label)}</td>'
                f'<td style="padding:8px 14px;border:1px solid #E8DEC9;font-family:Arial,sans-serif;'
                f'font-size:14px;color:#1C1917">{escape(value or "-")}</td></tr>')
    rows = (row("Tipo", a["tipo"]) + row("Nome", a["nome"]) + row("Telefone", a["telefone"]) +
            row("E-mail", a.get("email") or "-") + row("Data preferida", a.get("data_preferida") or "-") +
            row("Mensagem", a.get("mensagem") or "-"))
    return ('<table role="presentation" width="100%"><tr><td style="padding:24px;font-family:Arial,sans-serif;'
            'background:#FAF7F2">'
            f'<h2 style="color:#8B001D;font-family:Georgia,serif">Novo pedido de agendamento</h2>'
            f'<table role="presentation" style="border-collapse:collapse;background:#ffffff">{rows}</table>'
            '<p style="font-size:12px;color:#888;margin-top:16px">Enviado pelo site da Paróquia São Paulo Apóstolo — '
            'Carapicuíba. Nunca pedimos senhas ou dados bancários por e-mail.</p>'
            '</td></tr></table>')

@api_router.post("/agendamentos")
async def create_agendamento(input: AgendamentoIn, request: Request):
    if input.tipo not in BOOKING_TYPES:
        raise HTTPException(status_code=422, detail="Tipo de agendamento inválido")
    ip = request.client.host if request.client else "unknown"
    now = datetime.now(timezone.utc).timestamp()
    if now - _booking_rate.get(ip, 0) < 30:
        raise HTTPException(status_code=429, detail="Aguarde alguns segundos antes de enviar novamente.")
    _booking_rate[ip] = now
    doc = {"id": str(uuid.uuid4()), **input.model_dump(), "email": str(input.email) if input.email else None,
           "status": "novo", "created_at": datetime.now(timezone.utc).isoformat()}
    await db.agendamentos.insert_one(doc)
    doc.pop("_id", None)
    email_sent = True
    try:
        await send_email(to=SECRETARY_EMAIL, subject=f"Novo pedido de agendamento — {input.tipo}",
                         html=_booking_email_html(doc))
    except HTTPException:
        email_sent = False
    return {"status": "ok", "id": doc["id"], "email_sent": email_sent}

@api_router.get("/agendamentos")
async def list_agendamentos(user=Depends(get_current_user)):
    return await db.agendamentos.find({}, {"_id": 0}).sort("created_at", -1).to_list(200)


@api_router.get("/")
async def root():
    return {"message": "Hello World"}


# ---------------- WebTV (última transmissão) ----------------

_webtv_cache: dict = {}
YT_UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"}

@api_router.get("/webtv")
async def webtv():
    now = datetime.now(timezone.utc).timestamp()
    if _webtv_cache.get("data") and now - _webtv_cache.get("ts", 0) < 600:
        return _webtv_cache["data"]
    result = {"videoId": None, "live": False}
    try:
        async with httpx.AsyncClient(timeout=20, follow_redirects=True, headers=YT_UA) as http_client:
            live_resp = await http_client.get("https://www.youtube.com/@WebTvPSPA/live")
            m = re.search(r"[?&]v=([\w-]{11})", str(live_resp.url))
            if m:
                result = {"videoId": m.group(1), "live": True}
            else:
                streams_resp = await http_client.get("https://www.youtube.com/@WebTvPSPA/streams")
                ids = re.findall(r'"videoId":"([\w-]{11})"', streams_resp.text)
                if ids:
                    result = {"videoId": ids[0], "live": False}
    except Exception as e:
        logger.error(f"WebTV fetch error: {e}")
    _webtv_cache["data"] = result
    _webtv_cache["ts"] = now
    return result


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    await db.users.create_index("email", unique=True)
    await db.login_attempts.create_index("identifier")
    admin_email = os.environ.get("ADMIN_EMAIL", "admin@example.com").lower()
    admin_password = os.environ.get("ADMIN_PASSWORD", "admin123")
    existing = await db.users.find_one({"email": admin_email})
    if existing is None:
        await db.users.insert_one({"email": admin_email, "password_hash": hash_password(admin_password),
                                   "name": "Secretaria PSPA", "role": "admin",
                                   "created_at": datetime.now(timezone.utc).isoformat()})
        logger.info("Admin user seeded")
    elif not verify_password(admin_password, existing["password_hash"]):
        await db.users.update_one({"email": admin_email}, {"$set": {"password_hash": hash_password(admin_password)}})
        logger.info("Admin password updated from env")
    if await db.avisos.count_documents({}) == 0:
        await db.avisos.insert_many([
            {"id": str(uuid.uuid4()), **a, "created_at": datetime.now(timezone.utc).isoformat()}
            for a in DEFAULT_AVISOS
        ])
        logger.info("Default avisos seeded")


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
